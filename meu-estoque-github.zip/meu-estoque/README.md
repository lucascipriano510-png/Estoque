# Meu Estoque — Catálogo Pro

Aplicação web de catálogo e controle de estoque.

## Estrutura do projeto

- `index.html`: estrutura da página.
- `css/style.css`: estilos da aplicação.
- `js/app.js`: lógica JavaScript.
- `assets/images/`: pasta para imagens locais.

## Como executar

Abra `index.html` no navegador. A aplicação carrega Tailwind CSS, Font Awesome e a fonte Inter por CDN, então esses recursos externos precisam de internet. Os dados são armazenados no `localStorage` do navegador.

## Publicar no GitHub

Envie para o repositório todos os arquivos e pastas mantendo essa estrutura. Se usar GitHub Pages, configure a publicação a partir da branch e pasta onde está o `index.html`.
